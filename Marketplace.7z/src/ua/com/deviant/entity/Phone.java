package ua.com.deviant.entity;

public class Phone extends Product{

	public Phone(String name, Store store, Category category, Manufacturer manufacturer, int price) {
		super(name, store, category, manufacturer, price);
	}

	public Phone(int id, String name, Store store, Category category, Manufacturer manufacturer, int price) {
		super(id, name, store, category, manufacturer, price);
	}
	
	



	

}
